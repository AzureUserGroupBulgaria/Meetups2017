﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Demo1.Common
{
    public class ApplicationSecrets
    {
        public static bool UseKeyVault { get; set; }
        //Shared Secrets 
        public static string ConfigDatabaseName { get; set; }
        public static string ConfigDatabaseUser { get; set; }
        public static string ConfigDatabasePassword { get; set; }
        public static string ConfigDatabaseServer { get; set; }
        public static string SymetricKey { get; set; }
        //Shared Tenant Provisioning Secrets 
        public static string AzureSubscriptionId { get; set; }
        public static string Base64EncodedAzureMgmtVMCertificate { get; set; }
        public static string AzureSubscriptionUsername { get; set; }
        public static string AzureSubscriptionPassword { get; set; }
        public static string SolrVMUsername { get; set; }
        public static string SolrVMPassword { get; set; }
        //Tenant Related Secrets 
        public static string TenantDatabaseName { get; set; }
        public static string TenantDatabaseUser { get; set; }
        public static string TenantDatabasePassword { get; set; }
        public static string TenantDatabaseServer { get; set; }
    }
}