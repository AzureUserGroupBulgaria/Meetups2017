﻿using Dapper;
using Demo1.Common;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Web;

namespace Demo1.Services
{
    public class DbManagerBase : IDisposable
    {
        IDbConnection connection;

        protected IDbConnection MyConnection
        {
            get
            {
                if (connection == null)
                {
                    connection = new SqlConnection(GetConnectionString());
                    connection.Open();
                }
                else if (connection.State != ConnectionState.Open)
                {
                    connection.Close();
                    connection.Open();
                }
                return connection;
            }
        }

        private string GetConnectionString()
        {
            string configDatabaseServer = ApplicationSecrets.ConfigDatabaseServer;
            string configDatabaseName = ApplicationSecrets.ConfigDatabaseName;
            string configDatabaseUser = ApplicationSecrets.ConfigDatabaseUser;
            string configDatabasePassword = ApplicationSecrets.ConfigDatabasePassword;

return GetConnectionString(configDatabaseServer, configDatabaseName, configDatabaseUser, configDatabasePassword);
        }

        private string GetConnectionString(string databaseServer, string databaseName, string databaseUserId, string databasePassword)
        {
            

            var sb = new StringBuilder();
            sb.Append("Data Source=");
            sb.Append(databaseServer);
            sb.Append(";Initial Catalog=");
            sb.Append(databaseName);
            sb.Append(";User id=");
            sb.Append(databaseUserId);
            sb.Append(";Password=");
            sb.Append(databasePassword);
            sb.Append(";Integrated security=false;");
            // Needed for Always Encrypted. 
            bool isAlwaysEncryptedEnabled = false;
            Boolean.TryParse(ConfigurationManager.AppSettings["AlwaysEncryptedEnabled"], out isAlwaysEncryptedEnabled);
            if (isAlwaysEncryptedEnabled)
                sb.AppendFormat("Column Encryption Setting={0};", ConfigurationManager.AppSettings["AlwaysEncrypted"]);
            return sb.ToString();
        }

        protected internal IEnumerable<T> ExecuteRowQuery<T>(string sql, object parameters = null)
        {
            return MyConnection.Query<T>(new CommandDefinition(sql, parameters));
        }

        private void TerminateConnection()
        {
            if (connection != null)
            {
                connection.Close();
                connection.Dispose();
                connection = null;
            }
        }

        public void Dispose()
        {
            TerminateConnection();
        }
    }
}