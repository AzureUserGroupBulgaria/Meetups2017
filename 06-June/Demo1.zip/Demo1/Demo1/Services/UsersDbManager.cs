﻿using Demo1.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Dapper;

namespace Demo1.Services
{
    public class UsersDbManager : DbManagerBase
    {
        public List<Users> GetAllUsers()
        {
            var query = string.Format(@"SELECT [Id]

                                      ,[FirstName]
                                      ,[LastName]
                                      ,[EGN]
                                      ,[CreditCard]
                                  FROM [dbo].[Users]");
            return ExecuteRowQuery<Users>(query).ToList();
        }
    }
}