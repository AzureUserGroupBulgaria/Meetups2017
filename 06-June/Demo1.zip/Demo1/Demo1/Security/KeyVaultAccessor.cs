﻿using Microsoft.Azure.KeyVault;
using Microsoft.IdentityModel.Clients.ActiveDirectory;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Web;

namespace Demo1.Security
{
    public class KeyVaultAccessor
    {
        private static KeyVaultClient _keyVaultClient;
        private static string _clientId;
        private static string _clientSecret;
        public static KeyVaultClient KeyVaultClient
        {
            get
            {
                return _keyVaultClient;
            }
            set
            {
                _keyVaultClient = value;
            }
        }

        public static string ClientId
        {
            get
            {
                return _clientId;
            }
            set
            {
                _clientId = value;
            }
        }

        public static string ClientSecret
        {
            get
            {
                return _clientSecret;
            }
            set
            {
                _clientSecret = value;
            }
        }

        public string GetSecret(string secretId)
        {
            var secret = _keyVaultClient.GetSecretAsync(secretId).Result;
            return secret.Value;
        }

        //the method that will be provided to the KeyVaultClient
        public async static Task<string> GetToken(string authority, string resource, string scope)
        {
            var authContext = new AuthenticationContext(authority);
            ClientCredential clientCred = new ClientCredential(ClientId, ClientSecret);
            AuthenticationResult result = await authContext.AcquireTokenAsync(resource, clientCred);

            if (result == null)
                throw new InvalidOperationException("Failed to obtain the JWT token");

            return result.AccessToken;
        }
    }
}