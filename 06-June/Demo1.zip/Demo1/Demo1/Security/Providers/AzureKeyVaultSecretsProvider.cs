﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Web;

namespace Demo1.Security
{
    public class AzureKeyVaultSecretsProvider : IApplicationSecretsProvider
    {
        public string Get(string key, string keyVaultName = "")
        {
            KeyVaultAccessor keyVaultAccessor = new KeyVaultAccessor();
            string secretsVaultUrl = ConfigurationManager.AppSettings["SecretsVaultUrl"];
            if (!String.IsNullOrWhiteSpace(keyVaultName))
                secretsVaultUrl = "https://" + keyVaultName + ".vault.azure.net/secrets";
            return keyVaultAccessor.GetSecret(secretsVaultUrl + "/" + key);
        }
    }
}