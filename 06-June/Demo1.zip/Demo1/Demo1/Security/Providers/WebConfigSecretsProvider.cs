﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Web;

namespace Demo1.Security
{
    public class WebConfigSecretsProvider : IApplicationSecretsProvider
    {
        public string Get(string key, string keyVaultName = "")
        {
            return ConfigurationManager.AppSettings[key];
        }
    }
}