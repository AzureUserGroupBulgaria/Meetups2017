﻿using Demo1.Common;
using Demo1.Security;
using Microsoft.Azure.KeyVault;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Routing;

namespace Demo1
{
    public class MvcApplication : System.Web.HttpApplication
    {
        private static IApplicationSecretsProvider _applicationSecretsProvider;

        public static IApplicationSecretsProvider ApplicationSecretsProvider
        {
            get
            {
                return _applicationSecretsProvider;
            }
        }

        protected void Application_Start()
        {
            AreaRegistration.RegisterAllAreas();
            RouteConfig.RegisterRoutes(RouteTable.Routes);
           
            ApplicationSecrets.UseKeyVault = Convert.ToBoolean(ConfigurationManager.AppSettings["UseKeyVault"]);
            if (ApplicationSecrets.UseKeyVault)
            {
                KeyVaultAccessor.ClientId = ConfigurationManager.AppSettings["AuthClientId"];
                KeyVaultAccessor.ClientSecret = ConfigurationManager.AppSettings["AuthClientSecret"];
                KeyVaultAccessor.KeyVaultClient = new KeyVaultClient(new KeyVaultClient.AuthenticationCallback(KeyVaultAccessor.GetToken));

                _applicationSecretsProvider = new AzureKeyVaultSecretsProvider();
            }
            else
            {
                _applicationSecretsProvider = new WebConfigSecretsProvider();
            }

            ApplicationSecrets.ConfigDatabaseServer = ApplicationSecretsProvider.Get(ConfigurationManager.AppSettings["SecretConfigDatabaseServer"]);
            ApplicationSecrets.ConfigDatabaseName = ApplicationSecretsProvider.Get(ConfigurationManager.AppSettings["SecretConfigDatabaseName"]);
            ApplicationSecrets.ConfigDatabaseUser = ApplicationSecretsProvider.Get(ConfigurationManager.AppSettings["SecretConfigDatabaseUser"]);
            ApplicationSecrets.ConfigDatabasePassword = ApplicationSecretsProvider.Get(ConfigurationManager.AppSettings["SecretConfigDatabasePassword"]);            
        }
    }
}
